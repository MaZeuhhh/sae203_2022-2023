#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import sys
from validation import ip_validate, mac_validate
from dhcp import dhcp_add
from config import load_config, get_dhcp_server

def add_dhcp_client(mac, ip):
    
    """
        Cette fonction utilise les modules ip_validate, mac_validate, dhcp_add, load_config et get_dhcp_server. Elle permet de valider les argument qui lui sont donnés puis d'ajouter une configuration DHCP sur le serveur en question.
        Si les arguments fournis ne sont pas bons, alors elle renverra un message d'erreur en fonction de ceux-ci. Dans le cas contraire, elle va tenter d'ajouter cette configuration. 
        Néanmoins, selon la configuration déjà présente sur le serveur, il se peut que l'adresse IP voulue soit déjà attribuée à une autre adresse MAC. Dans ce cas, elle renverra un message d'erreur.
    """

    if mac_validate(mac) == True and ip_validate(ip) == True: #Vérification des arguments

        cfg = load_config("config.yaml", True)

        server = get_dhcp_server(ip, cfg)

        for key in server:

            if dhcp_add(ip, mac, key, cfg): #Si la fonction dhcp_add renvoie True alors le programme est validé

                return True

            else: #Sinon on envoie un message d'erreur

                print("error: IP address already in use.")

    elif mac_validate(mac) == False and ip_validate(ip) == True: #Seulement l'adresse MAC est fausse

        print("error: bad MAC address")

    elif mac_validate(mac) == True and ip_validate(ip) == False: #Seulement l'adresse IP est fausse

        print("error: bad IP address")

    elif mac_validate(mac) == False and ip_validate(ip) == False: #Les deux adresses sont fausses

        print("error: both MAC and IP addresses")





def main():

    add_dhcp_client(sys.argv[1], sys.argv[2])


if __name__ == '__main__':
    main()