#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import sys
from dhcp import dhcp_list
from config import load_config, get_dhcp_server



def check_dhcp(server):
    
    """
        Cette fonction utilise les modules dhcp_list, load_config et get_dhcp_server. Elle permet de vérifier la configuration DHCP d'un ou plusieurs serveurs. 
        Elle affiche des résultats lorsqu'il y a des doublons MAC ou IP. Si on lui donne en argument un serveur DHCP, elle ne vérifiera que ce serveur. 
        Dans le cas contraire, elle vérifiera tous les serveurs présents dans le fichier de configuration DHCP config.yaml.
    """
    
    cfg = load_config("config.yaml", True)

    if server != None: #Si un serveur est donné en argument

        ip_server = get_dhcp_server(server, cfg) 

        if ip_server == None: #Si l'adresse IP donnée n'est pas identifiable comme appartenant à un réseau spécifié dans config.yaml alors on affiche un message d'erreur

            print("Cannot identify DHCP server")

        else: #Si on peut l'identifier alors on va aller récupérer la configuration du fichier DHCP du serveur en question pour ensuite comparer.

            ip_server = list(ip_server.keys())[0]

            hosts = dhcp_list(ip_server, cfg)

            mac_dict = {}
            ip_dict = {}

            for line in hosts: #On parcourt chaque ligne dans les hôtes récupérés

                mac = line["mac"]
                ip = line["ip"]
                
                # Si l'adresse MAC existe déjà dans le dictionnaire mac_dict, on ajoute la ligne à la liste des lignes associées à cette MAC.
                # Sinon, on crée une nouvelle entrée dans le dictionnaire avec cette MAC et la ligne comme première entrée dans la liste.
                if mac in mac_dict:
                    mac_dict[mac].append(line)
                else:
                    mac_dict[mac] = [line]
                    
                # Si l'adresse IP existe déjà dans le dictionnaire ip_dict, on ajoute la ligne à la liste des lignes associées à cette IP.
                # Sinon, on crée une nouvelle entrée dans le dictionnaire avec cette IP et la ligne comme première entrée dans la liste.
                if ip in ip_dict:
                    ip_dict[ip].append(line)
                else:
                    ip_dict[ip] = [line]

            # On crée une liste des entrées où une même MAC est associée à plusieurs lignes.
            duplicate_macs = [entries for mac, entries in mac_dict.items() if len(entries) > 1]
            # On crée une liste des entrées où une même IP est associée à plusieurs lignes.
            duplicate_ips = [entries for ip, entries in ip_dict.items() if len(entries) > 1]

            if duplicate_macs: # S'il y a des adresses MAC en double, on affiche un message et les détails des entrées en double.
                print("duplicate MAC addresses:")
                for entries in duplicate_macs:
                    for entry in entries:
                        print(f"dhcp-host={entry['mac']},{entry['ip']}")
                    print()

            if duplicate_ips: # S'il y a des adresses IP en double, on affiche un message et les détails des entrées en double.
                print("duplicate IP addresses:")
                for entries in duplicate_ips:
                    for entry in entries:
                        print(f"dhcp-host={entry['mac']},{entry['ip']}")
                print()

    else: #Si un serveur n'est pas donné en argument

        for server in cfg["dhcp-servers"].keys(): #On parcourt les serveurs DHCP dans le fichier config.yaml

            print(server, ":")

            hosts = dhcp_list(server, cfg) #On liste le fichier de configuration DHCP du serveur visé

            mac_dict = {}
            ip_dict = {}

            for line in hosts: #On parcourt chaque ligne dans les hôtes récupérés

                mac = line["mac"]
                ip = line["ip"]
                
                # Si l'adresse MAC existe déjà dans le dictionnaire mac_dict, on ajoute la ligne à la liste des lignes associées à cette MAC.
                # Sinon, on crée une nouvelle entrée dans le dictionnaire avec cette MAC et la ligne comme première entrée dans la liste.
                if mac in mac_dict:
                    mac_dict[mac].append(line)
                else:
                    mac_dict[mac] = [line]

                # Si l'adresse IP existe déjà dans le dictionnaire ip_dict, on ajoute la ligne à la liste des lignes associées à cette IP.
                # Sinon, on crée une nouvelle entrée dans le dictionnaire avec cette IP et la ligne comme première entrée dans la liste.
                if ip in ip_dict:
                    ip_dict[ip].append(line)
                else:
                    ip_dict[ip] = [line]

            # On crée une liste des entrées où une même MAC est associée à plusieurs lignes.
            duplicate_macs = [entries for mac, entries in mac_dict.items() if len(entries) > 1]
            # On crée une liste des entrées où une même IP est associée à plusieurs lignes.
            duplicate_ips = [entries for ip, entries in ip_dict.items() if len(entries) > 1]

            if duplicate_macs: # S'il y a des adresses MAC en double, on affiche un message et les détails des entrées en double.
                print("duplicate MAC addresses:")
                for entries in duplicate_macs:
                    for entry in entries:
                        print(f"dhcp-host={entry['mac']},{entry['ip']}")
                    print()

            if duplicate_ips: # S'il y a des adresses IP en double, on affiche un message et les détails des entrées en double.
                print("duplicate IP addresses:")
                for entries in duplicate_ips:
                    for entry in entries:
                        print(f"dhcp-host={entry['mac']},{entry['ip']}")
                print()

def main():

    if len(sys.argv) > 1:

        check_dhcp(sys.argv[1])

    else:

        check_dhcp(None)

if __name__ == '__main__':
    main()