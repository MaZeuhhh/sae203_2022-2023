#! /usr/bin/env python3

#Importation des librairies nécessaires aux fonctions
import yaml
import os
import ipaddress

def load_config(filename, create):
    
    """
        Cette fonction permet charger un fichier de configuration, nous permettant de récupérer diverses informations à propos des serveurs, 
        de l'identifiant utilisateur permettant de se connecter au compte administrateur et d'obtenir le chemin absolu du fichier de configuration
        du service DHCP.
    """

    basic_conf = {'dhcp_hosts_cfg': '/etc/dnsmasq.d/hosts.conf', 'user': 'superv', 'password' : 'superv' 'dhcp-servers': {'10.20.1.5': '10.20.1.0/24', '10.20.2.5': '10.20.2.0/24'}}

    if os.path.exists(filename): #Si le chemin donné existe alors le fichier est chargé dans la configuration

        with open(filename, 'r', encoding='utf-8') as desc: 

            cfg = yaml.safe_load(desc)

    elif not os.path.exists(filename) and create == True: #Si le chemin donné n'existe pas mais que create est sur True, alors le fichier est créé et la configuration est chargée

        with open(filename, 'w', encoding='utf-8') as fdesc:

            content = yaml.dump(basic_conf, fdesc)

        print('File did not exist but create variable is set on True ; file created.')

    else: #Si le chemin donné n'existe pas et que la variable create est sur False

        print('Error: File does not exist and create variable is not set on True value.')

    return cfg
    


def get_dhcp_server(ip, cfg):
    
    """
        Cette fonction permet de récupérer le réseau auquel une adresse IP appartient en prenant en compte la configuration du fichier de configuration
        YAML. Elle renvoie ensuite un dictionnaire dont la clé est l'IP du serveur DHCP du réseau auquel appartient l'IP et l'adresse du réseau en valeur.
    """

    result = None

    servers = cfg['dhcp-servers']

    networks = list(servers.values()) #On créé une liste des adresses réseau comprises dans le fichier de configuration

    addr = ipaddress.ip_address(ip)

    iter = 0

    for network in networks: #On parcourt les réseaux du fichier de configuration

        n = ipaddress.ip_network(network)

        if addr in n:

            result = {list(servers.keys())[iter] : network} #On formate notre résultat dans un dictionnaire

        iter += 1

    return result