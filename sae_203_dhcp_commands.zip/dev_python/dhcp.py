#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import fabric
import yaml
import re

def ip_other_mac_exists(cnx, ip, mac, cfg):
    
    """
        Cette fonction vérifie si l'adresse IP donnée est déjà attribuée à une autre adresse MAC. Si c'est le cas, alors la fonction renvoie True.
        Autrement, elle renvoie False.
    """
    
    result = False

    test = cnx.run('du -b ' + cfg, hide=True) #On vérifie si le fichier est vide auquel cas nous n'avons rien à vérifier
    file_size = int(test.stdout.split()[0]) 

    if file_size != 0:

        dnsmasq_value = cnx.run("cat " + cfg, hide=True).stdout.split("\n") #Lecture du résultat de la commande en mettant dans un bon format pour les lire

        all_addresses = []
        for i in range(len(dnsmasq_value)-1):
            all_addresses.append(dnsmasq_value[i].split("=")[1]) #On récupère exclusivement les adresses MAC et IP

        ip_list = []
        mac_list = []
        for i in range(len(all_addresses)-1): #On sépare chaque adresse MAC et chaque adresse IP
            ip_list.append(all_addresses[i].split(",")[1])
            mac_list.append(all_addresses[i].split(",")[0])

        duplicate_ip = False
        duplicate_mac = False

        for i in range(len(ip_list)-1): #On fait une boucle qui va regarder petit à petit s'il y a des doublons et changer les booléens en fonction
            if ip_list[i] == ip:
                duplicate_ip = True
            
            if mac_list == mac:
                duplicate_mac = True

        if duplicate_mac == False and duplicate_ip == True:
            result = True

    return result

def mac_exists(cnx, mac, cfg):
    
    """
        Cette fonction vérifie si l'adresse MAC donnée en argument est déjà attribuée à une adresse IP 
    """
    
    result = False

    test = cnx.run('du -b ' + cfg, hide=True) #On vérifie si le fichier est vide auquel cas nous n'avons rien à vérifier
    file_size = int(test.stdout.split()[0])

    if file_size != 0:
        dnsmasq_value = cnx.run("cat " + cfg, hide=True).stdout.split("\n") #Lecture du résultat de la commande en mettant dans un bon format pour les lire

        for line in dnsmasq_value: #On fait une boucle dans laquelle on vérifie chaque élement et on les compare entre eux
            match = re.match(r"dhcp-host=([^,]+),", line)
            if match and match.group(1) == mac:
                result = True

    return result


def dhcp_add(ip, mac, server, cfg):
    
    """
        Cette fonction a pour objectif de modifier la configuration DHCP du serveur pour ajouter un couple d'adresses MAC et IP.
            - Si le couple n'existe pas, on le crée
            - Si l'adresse MAC existe déjà dans le fichier, on modifie son association en remplaçant l'ancienne adresse IP par la nouvelle
            - Si l'adresse IP est déjà attribuée, on renvoie un message d'erreur
        La fonction renvoie donc True dans les deux premiers cas et False dans le dernier cas.
    """

    user = cfg["user"]
    
    password = cfg["password"]

    cfg = cfg["dhcp_hosts_cfg"]

    cnx = fabric.Connection(server, user=user, connect_kwargs={"password": password}) #On établit la connection au serveur

    if ip_other_mac_exists(cnx, ip, mac, cfg) == False and mac_exists(cnx, mac, cfg) == False: #Condition dans laquelle ni l'adresse MAC, ni l'adresse IP ne sont présentes dans le fichier

        cnx.run(f"echo \"dhcp-host={mac},{ip}\" >> {cfg}", hide=True)

        cnx.run("sudo systemctl restart dnsmasq.service")

        result = True

    elif ip_other_mac_exists(cnx, ip, mac, cfg) == True and mac_exists(cnx, mac, cfg) == False: #Condition dans laquelle seulement l'adresse IP existe déjà dans le fichier

        result = False

    elif ip_other_mac_exists(cnx, ip, mac, cfg) == False and mac_exists(cnx, mac, cfg) == True: #Condition dans laquelle seulement l'adresse MAC existe déjà dans le fichier

        data = cnx.run(f"grep {mac} {cfg}", hide=True)
        line = data.stdout.strip()

        old_ip = line.split(",")[1]

        old_ip = re.escape(old_ip) #On échappe les caractères spéciaux ou les points et deux points pour éviter une quelconque erreur
        ip = re.escape(ip) #On échappe les caractères spéciaux ou les points et deux points pour éviter une quelconque erreur

        cnx.run(f"sed -i 's/{old_ip}/{ip}/g' {cfg}", hide=True)

        cnx.run("sudo systemctl restart dnsmasq.service")

        result = True

    return result


def dhcp_remove(mac, server, cfg):
    
    """
        Cette fonction supprime une association d'adresses MAC et IP dont on connaît l'adresse IP. Il y a deux cas de figure :
            - Si l'adresse MAC existe dans le fichier, alors on supprime la ligne qui la contient
            - Si l'adresse MAC n'existe pas dans le fichier, alors on renvoie une valeur d'erreur
    """

    password = cfg["password"]
    
    user = cfg["user"]

    cfg = cfg["dhcp_hosts_cfg"]

    cnx = fabric.Connection(server, user=user, connect_kwargs={"password": password}) #On établit la connection au serveur

    if mac_exists(cnx, mac, cfg) == True: #On teste si l'adresse MAC existe

        mac = re.escape(mac) #On échappe les caractères spéciaux ou les points et deux points pour éviter une quelconque erreur

        cnx.run(f"sed -i '/{mac}/d' {cfg}", hide=True)

        cnx.run("sudo systemctl restart dnsmasq.service")

    else:

        raise ValueError("No MAC Address found") #On retourne une valeur d'erreur car l'adresse MAC n'a pas été trouvée


def dhcp_list(server, cfg):
    
    """
        Cette fonction permet de lister le contenu d'un fichier de configuration d'un serveur DHCP.
        Elle renvoie le contenu sous la forme d'un dictionnaire avec deux élements, l'adresse MAC puis l'adresse IP.
    """

    user = cfg["user"]
    
    password = cfg["password"]

    result = []

    cfg = cfg["dhcp_hosts_cfg"]

    cnx = fabric.Connection(server, user=user, connect_kwargs={"password": password}) #On établit la connection au serveur

    dnsmasq_value = cnx.run("cat " + cfg, hide=True).stdout.split("\n") #Lecture du résultat de la commande en mettant dans un bon format pour les lire

    for line in dnsmasq_value: #On parcourt chaque ligne puis on envoie les valeurs dans le bon format dans une liste que l'on retourne

        if line.startswith("dhcp-host="):

            data = line.split("=")[1]

            mac, ip = data.split(",")

            result.append({"mac": mac, "ip": ip})

    return result