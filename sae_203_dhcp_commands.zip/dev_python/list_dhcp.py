#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import sys
from dhcp import dhcp_list
from config import load_config


def list_dhcp(server):
    
    """
        Cette fonction utilise les modules dhcp_list et load_config. Elle permet d'avoir un affichage clair et simplifié du fichier de configuration DHCP d'un ou plusieurs serveurs. 
        Si l'adresse IP d'un serveur est donnée en argument, on affichera seulement que la configuration DHCP de ce dernier. 
        Dans le cas contraire, on affichera une à une les configurations DHCP de tous les serveurs présents dans le fichier de configuration config.yaml.
    """

    result_dict = 0

    cfg = load_config("config.yaml", True)

    if server != None: #Si un serveur est donné en argument

        result_dict = dhcp_list(server, cfg)

        for addresses in result_dict: #On parcourt le dictionnaire et on print de manière claire et simplifiée

            mac = addresses["mac"]
            ip = addresses["ip"]

            print(mac, "\t", ip)

    else: #Si aucun serveur n'est donné en argument

        for server in cfg["dhcp-servers"].keys(): #On parcourt les serveurs du fichier de configuration config.yaml pour tous les faire un par un.

            result_dict = dhcp_list(server, cfg)

            print(server, ':')

            for addresses in result_dict:

                mac = addresses["mac"]
                ip = addresses["ip"]

                print(mac, "\t", ip)


def main():

    if len(sys.argv) > 1:

        list_dhcp(sys.argv[1])

    else:

        list_dhcp(None)




if __name__ == '__main__':
    main()