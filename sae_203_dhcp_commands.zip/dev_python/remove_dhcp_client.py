#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import sys
from validation import mac_validate
from dhcp import dhcp_remove
from config import load_config

def remove_dhcp_client(mac):
    
    """
        Cette fonction utilise les modules mac_validate, dhcp_remove et load_config. Elle permet de retirer une configuration DHCP d'une adresse MAC donnée en argument lors de l'appel de la fonction.
        La fonction va alors vérifier les configurations DHCP de chaque serveur DHCP pour trouver l'adresse MAC en question et supprimer la ligne qui la contient. Si l'on ne trouve pas l'adresse MAC dans les serveurs DHCP,
        alors on envoie un message d'erreur. Si l'adresse MAC n'est pas valide, on envoie également un message d'erreur.
    """

    count = 0

    if mac_validate(mac) == True: #Vérification de l'argument

        cfg = load_config("config.yaml", True)

        servers = cfg["dhcp-servers"]

        for server in servers.keys(): #On vérifie chaque serveur

            try:

                dhcp_remove(mac, server, cfg)

            except ValueError:

                count += 1

        if count == 2:

            print("MAC address not found")

    else:

        print("error: bad MAC address")





def main():

    remove_dhcp_client(sys.argv[1])


if __name__ == '__main__':
    main()