#! /usr/bin/env python3

#Importation des modules nécessaires aux fonctions
import re
import ipaddress

"""
    Ce module contient deux fonctions distinctes :
        - Une première qui vérifie si l'adresse IP donnée en argument est valide ou non
        - Une seconde qui vérifie si l'adresse MAC donnée en argument est valide ou non
"""

def ip_validate(ip):

    """
        Vérifie si l'adresse IP donnée en argument est valide ou non
    """

    result = 0

    try:
        ipaddress.ip_address(ip)
        result = True
    except ValueError:
        result = False

    return result

def mac_validate(mac):

    """
        Vérifie si l'adresse MAC donnée en argument est valide ou non
    """

    result = 0

    pattern = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')
    if re.match(pattern, mac):
        result = True
    else:
        result = False
    
    return result
